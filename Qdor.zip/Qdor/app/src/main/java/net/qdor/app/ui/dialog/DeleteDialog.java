package net.qdor.app.ui.dialog;

import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatTextView;
import android.view.View;

import net.qdor.app.R;
import net.qdor.app.ui.base.BaseDialog;

public class DeleteDialog extends BaseDialog {



    @Override
    public int getViewLayout() {
        return R.layout.dialog_delete;
    }

    @Override
    public void readView() {
        super.readView();
    }

    @Override
    public void functionView() {
        super.functionView();

    }

}
