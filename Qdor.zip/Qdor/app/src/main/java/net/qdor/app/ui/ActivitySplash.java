package net.qdor.app.ui;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.facebook.accountkit.Account;
import com.facebook.accountkit.AccountKit;
import com.facebook.accountkit.AccountKitCallback;
import com.facebook.accountkit.AccountKitError;
import com.facebook.accountkit.AccountKitLoginResult;
import com.facebook.accountkit.PhoneNumber;
import com.facebook.accountkit.ui.AccountKitActivity;
import com.facebook.accountkit.ui.AccountKitConfiguration;
import com.facebook.accountkit.ui.LoginType;

import net.qdor.app.R;
import net.qdor.app.application.G;
import net.qdor.app.application.Preference;
import net.qdor.app.data.Repository;
import net.qdor.app.data.interfaces.CallBack;
import net.qdor.app.data.remote.models.Api;
import net.qdor.app.data.remote.models.Login;
import net.qdor.app.data.remote.utils.RequestException;
import net.qdor.app.ui.base.BaseActivity;
import net.qdor.app.utils.Utils;


public class ActivitySplash extends BaseActivity {

    ProgressBar progressBar;
    Button btnLogin;

    //endregion
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        //   startActivity(new Intent(ActivitySplash.this, ActivityMain.class));
        readView();
        functionView();
        initViewModel();

    }

    @Override
    public void readView() {
        super.readView();
        btnLogin = findViewById(R.id.btnLogin);
        progressBar = findViewById(R.id.progressBar);
    }

    @Override
    public void functionView() {
        super.functionView();
        YoYo.with(Techniques.FadeInUp)
            .duration(1000)
            .playOn(findViewById(R.id.logo));

        Utils.runOnUIThread(new Runnable() {
            @Override
            public void run() {
                goNextStep();
            }
        }, 2000);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                phoneLogin();
            }
        });
    }

    private void goNextStep() {
        if (!Preference.isLogin()) {
            phoneLogin();
        } else {
            startActivity(new Intent(ActivitySplash.this, ActivityMain.class));
            finish();
        }

    }

    public static int APP_REQUEST_CODE = 99;

    public void phoneLogin() {
        final Intent intent = new Intent(this, AccountKitActivity.class);
        AccountKitConfiguration.AccountKitConfigurationBuilder configurationBuilder =
                new AccountKitConfiguration.AccountKitConfigurationBuilder(
                        LoginType.PHONE,
                        AccountKitActivity.ResponseType.TOKEN); // or .ResponseType.TOKEN
        // ... perform additional configuration ...
        intent.putExtra(
                AccountKitActivity.ACCOUNT_KIT_ACTIVITY_CONFIGURATION,
                configurationBuilder.build());
        startActivityForResult(intent, APP_REQUEST_CODE);

        /*AccessToken accessToken = AccountKit.getCurrentAccessToken();
        if (accessToken != null) {
            //Handle Returning User
            G.toast("accessToken");
        } else {

        }*/

    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        btnLogin.setVisibility(View.VISIBLE);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == APP_REQUEST_CODE) {
                AccountKitLoginResult loginResult = data.getParcelableExtra(AccountKitLoginResult.RESULT_KEY);

                if (loginResult.getError() != null) {
                    G.toast(Utils.getString(R.string.something_wrong));
                } else if (loginResult.wasCancelled()) {
                    G.toast(Utils.getString(R.string.login_cancelled));
                } else {
                    AccountKit.getCurrentAccount(new AccountKitCallback<Account>() {
                        @Override
                        public void onSuccess(final Account account) {
                            PhoneNumber phoneNumber = account.getPhoneNumber();
                            G.log("AccountKitError", "phoneNumber " + phoneNumber);
                            if (phoneNumber != null) {
                                String phoneNumberString = phoneNumber.getPhoneNumber();
                                String country_code = phoneNumber.getCountryCode();
                                btnLogin.setVisibility(View.VISIBLE);
                                checkLogin(country_code, phoneNumberString);
                            }
                        }

                        @Override
                        public void onError(final AccountKitError error) {
                            G.toast(Utils.getString(R.string.something_wrong));
                            G.log("AccountKitError", "error " + error.getUserFacingMessage());
                        }
                    });
                }
            }
        }
    }

    private void checkLogin(final String country_code, final String phone) {
        String no = "+" + country_code + phone;
        Repository.getInstance().getLogin(no, new CallBack<Api<Login>>() {
            @Override
            public void onSuccess(Api<Login> s) {
                super.onSuccess(s);
                if (!s.hasError()) {
                    // Preference.setToken(s.getEntry().getToken());
                    Preference.setIdUser(s.getEntry().getId());
                    Preference.setFirstName(s.getEntry().getFname());
                    Preference.setLastName(s.getEntry().getLname());
                    Preference.setPhone(s.getEntry().getPhone());

                    Intent intent = new Intent(ActivitySplash.this, ActivityRegister.class);
                    startActivity(intent);
                    finish();
                }
            }

            @Override
            public void onFail(RequestException e) {
                super.onFail(e);
                if (e.getCode() == 404) {
                    Intent intent = new Intent(ActivitySplash.this, ActivityRegister.class);
                    intent.putExtra("phone", phone);
                    intent.putExtra("country_code", country_code);
                    startActivity(intent);
                    finish();
                } else {
                    G.toast(Utils.getString(R.string.try_again));
                }
            }
        });
    }

    private void getProfile() {

    }
}