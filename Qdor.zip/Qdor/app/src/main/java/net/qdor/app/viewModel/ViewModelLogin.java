package net.qdor.app.viewModel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import net.qdor.app.application.Preference;
import net.qdor.app.data.Repository;
import net.qdor.app.data.interfaces.CallBack;
import net.qdor.app.data.remote.models.Login;
import net.qdor.app.data.remote.utils.RequestException;
import net.qdor.app.viewModel.impl.LoginView;
import net.qdor.app.viewModel.persenter.LoginPresenter;


public class ViewModelLogin extends AndroidViewModel implements LoginPresenter {
    private Repository repository;
    private LoginView  view;


    public ViewModelLogin(@NonNull Application application, Repository repository) {
        super(application);
        this.repository = repository;
    }

    @Override
    public void setLoginPresenter(LoginView presenter) {
        this.view = presenter;
    }

    @Override
    public void requestLogin(String userName, String pass) {
        if (view != null) {
            view.openLoading();
        }
    }
}
