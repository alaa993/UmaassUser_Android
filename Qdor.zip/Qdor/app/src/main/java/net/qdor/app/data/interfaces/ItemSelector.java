package net.qdor.app.data.interfaces;

/**
 * Created by khajavi on 9/10/2018.
 */

public interface ItemSelector<T> {
    void onSelect(T t);
}
