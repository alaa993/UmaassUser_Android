package net.qdor.app.interfac;

/**
 * Created by Younes on 25/06/2018.
 */

public interface IBackPress {
    boolean backPress();
}
