package net.qdor.app.data.remote;


import net.qdor.app.application.G;
import net.qdor.app.data.interfaces.CallBack;
import net.qdor.app.data.remote.models.Api;
import net.qdor.app.data.remote.models.Login;
import net.qdor.app.data.remote.service.ApiConnection;
import net.qdor.app.data.remote.service.ServiceApi;
import net.qdor.app.data.remote.utils.APIError;
import net.qdor.app.data.remote.utils.ErrorUtils;
import net.qdor.app.data.remote.utils.RequestException;
import net.qdor.app.data.remote.utils.RetryableCallback;

import retrofit2.Call;
import retrofit2.Response;

public class RemoteRepository implements RemoteSource {

    private static RemoteRepository INSTANCE;
    private ServiceApi service;
    private ApiConnection apiConnection;

    public static RemoteRepository getInstance() {
        if (INSTANCE == null) {
            synchronized (RemoteRepository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new RemoteRepository();
                }
            }
        }
        return INSTANCE;
    }

    private RemoteRepository() {
        apiConnection = ApiConnection.getInstance();
    }


    private <T> RetryableCallback<T> makeCallBack(final CallBack<T> callBack) {
        return makeCallBack(0, 0, callBack);
    }

    private <T> RetryableCallback<T> makeCallBack(int maxRetry, int maxTimerRetry, final CallBack<T> callBack) {
        return new RetryableCallback<T>(maxRetry, maxTimerRetry) {
            @Override
            public void onResponse(Call<T> call, Response<T> response) {
                super.onResponse(call, response);
                if (response.code() == 200 && response.body() != null && response.isSuccessful()) {
                    callBack.onSuccess(response.body());
                } else {
                    APIError apiError = ErrorUtils.parseError(apiConnection.getRetrofit(), response);
                    try {
                        callBack.onFail(new RequestException(apiError.message(), response.code()));
                    } catch (Exception e) {
                        e.printStackTrace();
                        callBack.onFail(new RequestException(response.message(), response.code()));
                    }
                }
            }

            @Override
            public void onFailure(Call<T> call, Throwable t) {
                super.onFailure(call, t);
                callBack.onFail(new RequestException(t.getMessage(), 0));

            }
        };
    }

    private void handleError(int code, String m) {
        String message = "خطایی رخ داد";
        switch (code) {
            case 400:
                message = "درخواست ناصحیح";
                break;
            case 401:
                message = "مجاز نیست";
                break;
            case 403:
                message = "تحریم";
                break;
            case 404:
                message = "پیدا نشد";
                break;
        }
        G.toast(message);
    }


    @Override
    public void getLogin(String phone, CallBack<Api<Login>> callBack) {
        apiConnection.getService()
                     .getLogin(phone)
                     .enqueue(makeCallBack(callBack));
    }
}
