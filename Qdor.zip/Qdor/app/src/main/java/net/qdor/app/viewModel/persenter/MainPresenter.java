package net.qdor.app.viewModel.persenter;


import net.qdor.app.viewModel.impl.MainView;

public interface MainPresenter {


    void setMainPresenter(MainView presenter);

}
