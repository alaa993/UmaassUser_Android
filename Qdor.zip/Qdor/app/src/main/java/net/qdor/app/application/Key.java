package net.qdor.app.application;


public class Key {
    public static String KEY_1 = "KEY_1";
    public static String KEY_2 = "KEY_2";
    public static String KEY_3 = "KEY_3";
    public static String KEY_4 = "KEY_4";
    public static String KEY_5 = "KEY_5";
    public static String KEY_6 = "KEY_7";
}
