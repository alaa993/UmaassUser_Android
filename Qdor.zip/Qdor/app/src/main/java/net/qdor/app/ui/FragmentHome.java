package net.qdor.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import net.qdor.app.R;
import net.qdor.app.data.remote.models.Category;
import net.qdor.app.interfac.ItemClickListener;
import net.qdor.app.ui.adapter.AdapterCategory;
import net.qdor.app.ui.adapter.AdapterDoctor;
import net.qdor.app.ui.base.BaseFragment;

import java.util.ArrayList;
import java.util.List;

public class FragmentHome extends BaseFragment {
    RecyclerView recyclerViewCategory;
    RecyclerView recyclerViewDoctor;
    Toolbar toolbar;
    private AdapterCategory adapterCategory;
    private AdapterDoctor adapterDoctor;


    @Override
    public int getViewLayout() {
        return R.layout.fragment_home;
    }

    @Override
    public void readView() {
        super.readView();
        recyclerViewCategory = baseView.findViewById(R.id.recyclerViewCategory);
        recyclerViewDoctor = baseView.findViewById(R.id.recyclerViewDoctor);
        toolbar = baseView.findViewById(R.id.toolbar);
    }


    @Override
    public void functionView() {
        super.functionView();
        adapterCategory = new AdapterCategory();
        LinearLayoutManager categoryManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerViewCategory.setLayoutManager(categoryManager);
        recyclerViewCategory.setAdapter(adapterCategory);

        adapterDoctor = new AdapterDoctor();
        adapterDoctor.setListener(new ItemClickListener<Category>() {
            @Override
            public void onClick(Category item) {
                Intent intent = new Intent(getActivity(), ActivityAppointment.class);
                startActivity(intent);
            }
        });
        adapterDoctor.setBookLitener(new ItemClickListener<Category>() {
            @Override
            public void onClick(Category item) {
                Intent intent = new Intent(getActivity(), ActivityBook.class);
                startActivity(intent);
            }
        });
        LinearLayoutManager doctorManager = new LinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        recyclerViewDoctor.setLayoutManager(doctorManager);
        recyclerViewDoctor.setAdapter(adapterDoctor);

    }
}
