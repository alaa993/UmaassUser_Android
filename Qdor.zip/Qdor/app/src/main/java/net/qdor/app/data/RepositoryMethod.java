package net.qdor.app.data;


import net.qdor.app.data.interfaces.CallBack;
import net.qdor.app.data.remote.RemoteSource;
import net.qdor.app.data.remote.models.Login;

public interface RepositoryMethod extends RemoteSource {



}
