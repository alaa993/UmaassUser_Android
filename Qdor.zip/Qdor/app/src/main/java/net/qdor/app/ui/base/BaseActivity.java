package net.qdor.app.ui.base;


import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import net.qdor.app.R;

import io.github.inflationx.viewpump.ViewPumpContextWrapper;


public class BaseActivity extends AppCompatActivity {

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
    }

    //=====================================
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enhance);

    }

    @Override
    protected void onResume() {
        super.onResume();
    }


    public void readView() {

    }

    public void functionView() {

    }

    public void initViewModel() {

    }

}//END
