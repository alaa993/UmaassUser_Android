package net.qdor.app.interfac;



public interface ItemClickListener<T> {
    void onClick(T item);
}
