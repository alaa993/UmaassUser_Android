package net.qdor.app.ui.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import net.qdor.app.ui.FragmentBooksDeleted;
import net.qdor.app.ui.FragmentBooksFuture;
import net.qdor.app.ui.FragmentBooksPast;

public class PagerAdapter extends FragmentStatePagerAdapter {

    public PagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new FragmentBooksFuture();
            case 1:
                return new FragmentBooksPast();
            case 2:
                return new FragmentBooksDeleted();
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return 3;
    }
}