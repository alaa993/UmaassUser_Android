package net.qdor.app.ui;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import net.qdor.app.R;
import net.qdor.app.ui.base.BaseActivity;
import net.qdor.app.ui.components.RoundCornerButton;


public class ActivityWelcome extends BaseActivity {
    RoundCornerButton btnRegister;
    RoundCornerButton btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        readView();
        functionView();
        initViewModel();
    }

    @Override
    public void readView() {
        btnRegister = findViewById(R.id.btnRegister);
        btnLogin = findViewById(R.id.btnLogin);
    }

    @Override
    public void functionView() {
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ActivityWelcome.this, ActivityLogin.class));
            }
        });
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ActivityWelcome.this, ActivityLogin.class));
            }
        });
    }


}
