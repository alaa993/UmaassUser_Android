package net.qdor.app.ui.base;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import net.qdor.app.R;
import net.qdor.app.interfac.IBackPress;


public abstract class BaseFragment extends Fragment implements IBackPress {
    public int baseViewId = getViewLayout();
    public View baseView;

    public abstract int getViewLayout();

    public void readView() {

    }

    public void functionView() {

    }

    public void initViewModel() {

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        baseView = inflater.inflate(baseViewId, container, false);
        return baseView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        readView();
        functionView();
        initViewModel();
    }

    @Override
    public boolean backPress() {
        return true;
    }

    public interface FragmentNavigation {
        void pushFragment(Fragment fragment);
    }

    public interface Callback {

        void onFragmentAttached();

        void onFragmentDetached(String tag);
    }
}
