package net.qdor.app.data.remote.service;


import net.qdor.app.application.BuildVars;
import net.qdor.app.application.G;
import net.qdor.app.data.MockServiceData;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import okhttp3.Cache;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.mock.BehaviorDelegate;
import retrofit2.mock.MockRetrofit;
import retrofit2.mock.NetworkBehavior;

public class ApiConnection {

    private static volatile ApiConnection INSTANCE;
    private ServiceApi serviceApi;
    private Retrofit retrofit;
    private MockServiceData serviceData;

    public static ApiConnection getInstance() {
        if (INSTANCE == null) {
            synchronized (ApiConnection.class) {
                if (INSTANCE == null) {
                    INSTANCE = new ApiConnection();
                }
            }
        }
        return INSTANCE;
    }

    private ApiConnection() {
        retrofit = create();
    }

    public Retrofit getRetrofit() {
        return retrofit;
    }

    public ServiceApi getService() {
        if (serviceApi == null) {
            NetworkBehavior behavior = NetworkBehavior.create();
            MockRetrofit mockRetrofit = new MockRetrofit.Builder(retrofit)
                    .networkBehavior(behavior)
                    .build();

            BehaviorDelegate<ServiceApi> delegate = mockRetrofit.create(ServiceApi.class);
            MockServiceData.MockService service = new MockServiceData.MockService(delegate);
            behavior.setDelay(1000, TimeUnit.MILLISECONDS);

            serviceApi = retrofit.create(ServiceApi.class)/*service*/;
        }
        return serviceApi;
    }

    private Retrofit create() {
        int cacheSize = 20 * 1024 * 1024;
        Cache cache = new Cache(G.getInstance().getCacheDir(), cacheSize);
        OkHttpClient.Builder client = new OkHttpClient.Builder();
        if (BuildVars.DEBUG_VERSION) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(HttpLoggingInterceptor.Level.BODY);
            client.addInterceptor(logging);
        }

        client.addInterceptor(new Interceptor() {
            @Override
            public okhttp3.Response intercept(Chain chain) throws IOException {
                Request newRequest = chain.request().newBuilder()
                                          /* .addHeader("Authorization", "Bearer " + Preference.getToken())*/
                                          .addHeader("Content-Type", "application/json")
                                          .build();
                return chain.proceed(newRequest);
            }
        });

        client.connectTimeout(5, TimeUnit.SECONDS)
              .readTimeout(30, TimeUnit.SECONDS)
              .writeTimeout(30, TimeUnit.SECONDS)
              .retryOnConnectionFailure(true)
              .cache(cache)
              .build();

        retrofit = new Retrofit.Builder()
                .client(client.build())
                .baseUrl(BuildVars.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        return retrofit;

    }

    public void clear() {
        INSTANCE = null;
        retrofit = null;
        serviceApi = null;
    }
}
