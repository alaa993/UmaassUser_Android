package net.qdor.app.data.remote;


import net.qdor.app.data.interfaces.CallBack;
import net.qdor.app.data.remote.models.Api;
import net.qdor.app.data.remote.models.Login;

public interface RemoteSource {


    void getLogin(String phone,
                  CallBack<Api<Login>> callBack);


}
