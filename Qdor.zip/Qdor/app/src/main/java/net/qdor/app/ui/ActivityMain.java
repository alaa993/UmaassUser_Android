package net.qdor.app.ui;


import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;

import net.qdor.app.R;
import net.qdor.app.utils.Utils;
import net.qdor.app.ui.base.BaseActivity;
import net.qdor.app.ui.base.BaseFragment;

import net.qdor.app.utils.backStackManager.FragNavController;
import net.qdor.app.utils.backStackManager.FragmentHistory;

public class ActivityMain extends BaseActivity implements
                                               BaseFragment.FragmentNavigation,
                                               FragNavController.TransactionListener,
                                               AHBottomNavigation.OnTabSelectedListener,
                                               FragNavController.RootFragmentListener {
    String[] TABS;
    private AHBottomNavigation bottomNavigation;
    private FragNavController mNavController;
    private FragmentHistory fragmentHistory;
    private int[] mTabIconsSelected = {
            R.drawable.ic_home_black_24dp,
            R.drawable.ic_map_black_24dp,
            R.drawable.ic_date_range_black_24dp,
            R.drawable.ic_person_black_24dp};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        readView();
        functionView();

        fragmentHistory = new FragmentHistory();

        mNavController = FragNavController.newBuilder(savedInstanceState, getSupportFragmentManager(), R.id.root)
                                          .transactionListener(this)
                                          .rootFragmentListener(this, TABS.length)
                                          .build();
    }

    @Override
    public void readView() {
        super.readView();
        bottomNavigation = findViewById(R.id.bottom_navigation);
    }

    @Override
    public void functionView() {
        super.functionView();
        setupBottomNav();
    }

    private void setupBottomNav() {

        TABS = getResources().getStringArray(R.array.tab_name);
        for (int i = 0; i < TABS.length; i++) {
            bottomNavigation.addItem(new AHBottomNavigationItem(TABS[i], mTabIconsSelected[i]));
        }
        bottomNavigation.setUseElevation(true);
        bottomNavigation.setDefaultBackgroundColor(Utils.getColor(R.color.card_color));
        bottomNavigation.setInactiveColor(Utils.getColor(R.color.colorAccent));
        bottomNavigation.setAccentColor(Utils.getColor(R.color.colorPrimary));
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.ALWAYS_SHOW);
        bottomNavigation.setColoredModeColors(Utils.getColor(R.color.white), Color.BLACK);
        bottomNavigation.setBehaviorTranslationEnabled(false);
        bottomNavigation.setOnTabSelectedListener(this);
    }

    private void switchTab(int position) {
        mNavController.switchTab(position);
    }

    @Override
    public void pushFragment(Fragment fragment) {
        if (mNavController != null) {
            mNavController.pushFragment(fragment);
        }
    }

    @Override
    public Fragment getRootFragment(int index) {
        switch (index) {
            case FragNavController.TAB1:
                return new FragmentHome();
            case FragNavController.TAB2:
                return new FragmentMap();
            case FragNavController.TAB3:
                return new FragmentBooks();
            case FragNavController.TAB4:
                return new FragmentProfile();
        }
        throw new IllegalStateException("Need to send an index that we know");
    }

    @Override
    public void onTabTransaction(Fragment fragment, int index) {

    }

    @Override
    public void onFragmentTransaction(Fragment fragment, FragNavController.TransactionType transactionType) {
    }

    @Override
    public boolean onTabSelected(int position, boolean wasSelected) {
        if (wasSelected) {
            mNavController.clearStack();
            switchTab(position);
        } else {
            fragmentHistory.push(position);
            switchTab(position);
        }

        return true;
    }

    @Override
    public void onBackPressed() {
        if (mNavController.getCurrentFrag() instanceof BaseFragment) {
            BaseFragment baseFragment = (BaseFragment) mNavController.getCurrentFrag();
            if (baseFragment.backPress()) {
                checkBack();
            }
        } else {
            checkBack();
        }

    }

    private void checkBack() {
        if (!mNavController.isRootFragment()) {
            mNavController.popFragment();
            BaseFragment baseFragment = (BaseFragment) mNavController.getCurrentFrag();
            baseFragment.backPress();
        } else {
            if (fragmentHistory.isEmpty()) {
                super.onBackPressed();
            } else {
                if (fragmentHistory.getStackSize() > 1) {
                    int position = fragmentHistory.popPrevious();
                    switchTab(position);
                    updateTabSelection(position);

                } else {
                    switchTab(TABS.length - 1);
                    updateTabSelection(TABS.length - 1);
                    fragmentHistory.emptyStack();
                }
            }

        }
    }

    private void updateTabSelection(int currentTab) {
        bottomNavigation.setOnTabSelectedListener(null);
        bottomNavigation.setCurrentItem(currentTab);
        bottomNavigation.setOnTabSelectedListener(this);
    }


}
