package net.qdor.app.viewModel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

import net.qdor.app.data.Repository;
import net.qdor.app.viewModel.impl.MainView;


public class ViewModelMain extends AndroidViewModel {
    private Repository repository;
    private MainView   presenter;
    public ViewModelMain(@NonNull Application application, Repository repository) {
        super(application);
        this.repository = repository;
    }
}
