package net.qdor.app.ui;


import android.os.Bundle;

import net.qdor.app.R;
import net.qdor.app.ui.base.BaseActivity;


public class ActivityRegister extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        readView();
        functionView();
        initViewModel();
    }

    @Override
    public void readView() {
    }

    @Override
    public void functionView() {
    }


}
