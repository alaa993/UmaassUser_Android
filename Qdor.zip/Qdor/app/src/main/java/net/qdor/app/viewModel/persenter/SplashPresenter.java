package net.qdor.app.viewModel.persenter;


import net.qdor.app.viewModel.impl.SplashView;

public interface SplashPresenter  {

    void getToken(String user, String pass, String deviceCode);

    void setSplashView(SplashView presenter);
}
