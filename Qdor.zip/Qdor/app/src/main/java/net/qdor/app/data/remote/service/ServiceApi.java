package net.qdor.app.data.remote.service;


import net.qdor.app.data.remote.models.Api;
import net.qdor.app.data.remote.models.Category;
import net.qdor.app.data.remote.models.Login;
import net.qdor.app.data.remote.models.Register;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ServiceApi {

    @FormUrlEncoded
    @POST("/api/login")
    Call<Api<Login>> getLogin(@Field("phone") String phone);

    @FormUrlEncoded
    @POST("/api/Register")
    Call<Api<Register>> register(@Field("fname") String fname, @Field("lname") String lname, @Field("phone") String phone);

    @POST("/api/MainCategories")
    Call<Api<Category>> getMainCategories();

    @FormUrlEncoded
    @POST("/api/Subcats")
    Call<Api<Register>> getSubcats(@Field("fname") String fname, @Field("lname") String lname, @Field("phone") String phone);


}
