package net.qdor.app.data.interfaces;


import android.arch.lifecycle.LiveData;

import net.qdor.app.data.remote.utils.RequestException;

import java.util.List;

public abstract class CallBack<T> implements CallBacks<T> {
    @Override
    public void onSuccess(T t) {

    }

    @Override
    public void onFail(RequestException e) {

    }

}
