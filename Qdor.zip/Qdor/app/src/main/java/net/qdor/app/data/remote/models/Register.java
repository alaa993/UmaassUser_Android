package net.qdor.app.data.remote.models;

import com.google.gson.annotations.SerializedName;

public class Register{

	@SerializedName("msg")
	private String msg;

	@SerializedName("error")
	private int error;

	@SerializedName("token")
	private String token;

	public void setMsg(String msg){
		this.msg = msg;
	}

	public String getMsg(){
		return msg;
	}

	public void setError(int error){
		this.error = error;
	}

	public int getError(){
		return error;
	}

	public void setToken(String token){
		this.token = token;
	}

	public String getToken(){
		return token;
	}
}