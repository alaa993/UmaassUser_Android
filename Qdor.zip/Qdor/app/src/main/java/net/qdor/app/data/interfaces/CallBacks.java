package net.qdor.app.data.interfaces;


import net.qdor.app.data.remote.utils.RequestException;

public interface CallBacks<T> {
    void onSuccess(T t);

    void onFail(RequestException e);
}