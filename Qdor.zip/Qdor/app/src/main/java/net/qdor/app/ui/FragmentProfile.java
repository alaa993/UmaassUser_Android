package net.qdor.app.ui;

import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import net.qdor.app.R;
import net.qdor.app.ui.adapter.AdapterBookMark;
import net.qdor.app.ui.base.BaseFragment;
import net.qdor.app.ui.dialog.EditProfileDialog;
import net.qdor.app.ui.dialog.SearchDialog;

public class FragmentProfile extends BaseFragment {

    AppCompatButton btn_edit_profile;
    RecyclerView recyclerView;
    private AdapterBookMark adapterBookMark;

    @Override
    public int getViewLayout() {
        return R.layout.fragment_profile;
    }


    @Override
    public void readView() {
        super.readView();
        recyclerView = baseView.findViewById(R.id.recyclerView);
        btn_edit_profile = baseView.findViewById(R.id.btn_edit_profile);
    }


    @Override
    public void functionView() {
        super.functionView();
        adapterBookMark = new AdapterBookMark();
        LinearLayoutManager categoryManager = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(categoryManager);
        recyclerView.setAdapter(adapterBookMark);
        btn_edit_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditProfileDialog cityDialog = new EditProfileDialog();
                cityDialog.show(getChildFragmentManager(), "cityDialog");
            }
        });

    }

}
