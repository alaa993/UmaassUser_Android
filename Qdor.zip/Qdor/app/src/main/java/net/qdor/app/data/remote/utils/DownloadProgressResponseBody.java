package net.qdor.app.data.remote.utils;

public class DownloadProgressResponseBody {
}
