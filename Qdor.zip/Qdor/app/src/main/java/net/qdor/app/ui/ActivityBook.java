package net.qdor.app.ui;


import android.os.Bundle;

import com.stepstone.stepper.StepperLayout;

import net.qdor.app.R;
import net.qdor.app.ui.adapter.MyStepperAdapter;
import net.qdor.app.ui.base.BaseActivity;

public class ActivityBook extends BaseActivity {

    StepperLayout stepperLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);
        readView();
        functionView();
    }

    @Override
    public void readView() {
        super.readView();
        stepperLayout = findViewById(R.id.stepperLayout);
    }

    @Override
    public void functionView() {
        super.functionView();
        stepperLayout.setAdapter(new MyStepperAdapter(getSupportFragmentManager(), this));
    }


}
