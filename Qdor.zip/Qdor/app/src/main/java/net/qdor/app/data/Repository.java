package net.qdor.app.data;


import net.qdor.app.data.interfaces.CallBack;
import net.qdor.app.data.remote.RemoteRepository;
import net.qdor.app.data.remote.models.Api;
import net.qdor.app.data.remote.models.Login;


public class Repository implements RepositoryMethod {

    private static Repository INSTANCE;
    RemoteRepository remoteRepository;

    public static Repository getInstance() {
        if (INSTANCE == null) {
            synchronized (Repository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new Repository();

                }
            }
        }
        return INSTANCE;
    }

    private Repository() {
        this.remoteRepository = RemoteRepository.getInstance();
    }


    @Override
    public void getLogin(String phone, CallBack<Api<Login>> callBack) {
        remoteRepository.getLogin(phone, callBack);
    }

}
