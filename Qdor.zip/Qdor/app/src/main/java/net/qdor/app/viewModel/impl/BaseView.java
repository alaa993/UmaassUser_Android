package net.qdor.app.viewModel.impl;


public interface BaseView {

    void openLoading();

    void closeLoading();

}
