package net.qdor.app.ui;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.stepstone.stepper.BlockingStep;
import com.stepstone.stepper.StepperLayout;
import com.stepstone.stepper.VerificationError;

import net.qdor.app.R;
import net.qdor.app.ui.adapter.AdapterTime;
import net.qdor.app.ui.base.BaseFragment;

public class FragmentBooksStepOne extends BaseFragment implements BlockingStep {


    AdapterTime adapterMonth = new AdapterTime();
    AdapterTime adapterDay = new AdapterTime();
    AdapterTime adapterTime = new AdapterTime();
    RecyclerView listMonth;
    RecyclerView listDay;
    RecyclerView listTime;


    @Override
    public int getViewLayout() {
        return R.layout.fragment_books_step_one;
    }
    @Override
    public void readView() {
        super.readView();
        listMonth = baseView.findViewById(R.id.listMonth);
        listDay = baseView.findViewById(R.id.listDay);
        listTime = baseView.findViewById(R.id.listTime);
    }

    @Override
    public void functionView() {
        super.functionView();
        LinearLayoutManager managerMonth = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        listMonth.setLayoutManager(managerMonth);
        listMonth.setAdapter(adapterMonth);

        LinearLayoutManager managerDay = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        listDay.setLayoutManager(managerDay);
        listDay.setAdapter(adapterDay);

        LinearLayoutManager managerTime = new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false);
        listTime.setLayoutManager(managerTime);
        listTime.setAdapter(adapterTime);

    }

    private void getData() {

    }

    @Override
    public void onNextClicked(StepperLayout.OnNextClickedCallback callback) {
        callback.goToNextStep();
    }

    @Override
    public void onCompleteClicked(StepperLayout.OnCompleteClickedCallback callback) {
        callback.complete();
    }

    @Override
    public void onBackClicked(StepperLayout.OnBackClickedCallback callback) {
        callback.goToPrevStep();
    }

    @Nullable
    @Override
    public VerificationError verifyStep() {
        return null;
    }

    @Override
    public void onSelected() {

    }

    @Override
    public void onError(@NonNull VerificationError error) {

    }
}
