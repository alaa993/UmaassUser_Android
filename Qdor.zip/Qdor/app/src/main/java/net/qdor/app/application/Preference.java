package net.qdor.app.application;


import java.util.UUID;

public class Preference {

    public static boolean isLogin() {
        return getIdUser() != 0;
    }

    public static void setIdUser(int idUser) {
        G.sharedPref.edit().putInt("idUser", idUser).apply();
    }

    public static int getIdUser() {
        return G.sharedPref.getInt("idUser", 0);
    }

    public static void setFirstName(String firstName) {
        G.sharedPref.edit().putString("firstName", firstName).apply();
    }

    public static void setLastName(String lastName) {
        G.sharedPref.edit().putString("lastName", lastName).apply();
    }

    public static void setPhone(String phone) {
        G.sharedPref.edit().putString("phone", phone).apply();
    }

    public static void setToken(String token) {
        G.sharedPref.edit().putString("token", token).apply();
    }


    public static String getPhone() {
        return G.sharedPref.getString("phone", null);
    }

    public static String getFirstName() {
        return G.sharedPref.getString("firstName", null);
    }

    public static String getLastName() {
        return G.sharedPref.getString("lastName", null);
    }

    public static String getToken() {
        return G.sharedPref.getString("token", null);
    }

    public static int getIdLanguage() {
        return G.sharedPref.getInt("idLanguage", 1);
    }

    public static void setDeviceId(String deviceId) {
        G.sharedPref.edit().putString("deviceId", deviceId).apply();
    }

    public static String getDeviceId() {
        String idDevice = G.sharedPref.getString("deviceId", null);
        if (idDevice == null) {
            setDeviceId(UUID.randomUUID().toString());
        }
        return G.sharedPref.getString("deviceId", UUID.randomUUID().toString());
    }


}
