package net.qdor.app.viewModel.persenter;


import net.qdor.app.viewModel.impl.LoginView;

public interface LoginPresenter  {
    void setLoginPresenter(LoginView presenter);

    void requestLogin(String userName, String pass);
//    void sendData(ModeleRequestContiner cmd);

   /* void requestVersionApp(RepositoryMethod.CallBacks<VersionApp> callback);
    void requesdownloadNewVersion(VersionApp app, DownloaderListener downloaderListener);*/

}
