package net.qdor.app.data.remote.models;

import com.google.gson.annotations.SerializedName;

public class LoginData {

}