package net.qdor.app.viewModel.impl;


public interface MainView extends BaseView {
}
