package net.qdor.app.viewModel.impl;


public interface LoginView extends BaseView {
    void onSuccessLogin();
}
